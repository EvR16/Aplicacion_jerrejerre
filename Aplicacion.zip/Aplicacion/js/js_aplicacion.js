            $(document).ready(function(){
             document.getElementById("envio").disabled = true;
        $('#boton2').change(function() 
    { 
        var file = $('#boton2').val(); 
        
        if(file=='') 
        { 
    document.getElementById("envio").disabled = true;
        } 
       else
         {
    document.getElementById("envio").disabled = false;
    $("#envio").click(function(){
     document.subir_archivo.action='subirarchivo.php';
    document.subir_archivo.submit();          
    });
    }

    });     
});
           
    
   