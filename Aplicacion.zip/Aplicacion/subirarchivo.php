<?php        $bd = new mysqli("localhost","root","","");

	
      $fname = $_FILES['txt']['name'];
         $chk_ext = explode(".",$fname);
 
         if(strtolower(end($chk_ext)) == "txt")
         {
             $filename = $_FILES['txt']['tmp_name'];
             $handle = fopen($filename, "r");
             $cont=0;
             while (($data1 = fgetcsv($handle, 1000, ",")) !== FALSE)
             {
                 if($data1[3]==""){
                   $cont=$cont+1;
                 } 
             }
              fclose($handle);
             $filename1 = $_FILES['txt']['tmp_name'];
             $handle1 = fopen($filename1, "r");
             if($cont==0){            
               while (($data = fgetcsv($handle1, 1000, ",")) !== FALSE){
                  var_dump($data[3]);
                switch ($data[3]) {
                         case '1':
                       $sql=$bd->query("INSERT INTO datos.`usuarios_activos`(`email`, `nombre`, `apellido`) VALUES ('$data[0]','$data[1]','$data[2]')");
                             break;
                          case '2':
                       $sql=$bd->query("INSERT INTO datos.`usuarios_inactivos`(`email`, `nombre`, `apellido`) VALUES ('$data[0]','$data[1]','$data[2]')");
                             break;
                          case '3':
                       $sql=$bd->query("INSERT INTO datos.`usuarios_espera`(`email`, `nombre`, `apellido`) VALUES ('$data[0]','$data[1]','$data[2]')");
                             break;

                     }                                
               }  
   fclose($handle);
   echo "<script>window.location.href='tabla.php'</script>";
             }else{
                 echo "<script>alert('El archivo no tiene el formato correcto')</script>";
                    echo "<script>window.location.href='inicio2.php'</script>";

             }

            
         }
         else
         {
          
             echo "Archivo invalido!";
         }
    
 
?>